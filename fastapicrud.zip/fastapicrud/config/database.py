from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker ,scoped_session
from fastapi_mail import ConnectionConfig


Base= declarative_base()


SQLALCHEMY_DB_URL=("mysql+mysqlconnector://root@localhost:3306/users")

engine= create_engine(SQLALCHEMY_DB_URL)

conn=engine.connect()

SessionLocal = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))

def get_db():
    db = SessionLocal
    try:
        yield db
    finally:
        db.close()



# class Config:
#     orm_mode = True

    




# MAIL SMTP DATA


conf = ConnectionConfig(
        MAIL_USERNAME="no-reply@lokaly.in",
        MAIL_PASSWORD="sfk239sjd34o*",
        MAIL_FROM="no-reply@lokaly.in",
        MAIL_PORT=465,
        MAIL_SERVER="mail.lokaly.in",
        MAIL_STARTTLS = False,
        MAIL_SSL_TLS = True,
        USE_CREDENTIALS=True,
    )



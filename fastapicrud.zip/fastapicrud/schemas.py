from pydantic import BaseModel,List,CoreModel
from pydantic import EmailStr


class UserSchemas(BaseModel):
        id =int
        name=str
        email = str
        password=str
        phone_no=int
        address=str
        city=str
        state=str
        Country=str
        zip=int
        photo=str


class EmailSchema(BaseModel):
    email: List[EmailStr]



class UserCreate(CoreModel):
    """
    Email, username, and password are required for registering a new user
    """
    email: "no-reply@lokaly.in"
    password: "sfk239sjd34o*"(min_length=7, max_length=100)
    username: "no-reply@lokaly.in"

    @validator("username", pre=True)
    def username_is_valid(cls, username: str) -> str:
        return validate_username(username)

    class Config:
        orm_mode = True